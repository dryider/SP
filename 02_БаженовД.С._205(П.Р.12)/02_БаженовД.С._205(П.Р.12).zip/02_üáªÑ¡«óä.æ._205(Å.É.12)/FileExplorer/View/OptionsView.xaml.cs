﻿using System.Windows.Controls;

namespace FileExplorer.View
{
    public partial class OptionsView : UserControl
    {
        public OptionsView()
        {
            InitializeComponent();
        }
    }
}
