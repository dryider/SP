﻿using DevExpress.Xpf.Core;

namespace FileExplorer.View
{
    public partial class CustomMenuView : DXWindow
    {
        public CustomMenuView()
        {
            InitializeComponent();
        }
    }
}
