﻿using DevExpress.Xpf.Core;

namespace FileExplorer.View
{
    public partial class CustomColumnView : DXWindow
    {
        public CustomColumnView()
        {
            InitializeComponent();
        }
    }
}
