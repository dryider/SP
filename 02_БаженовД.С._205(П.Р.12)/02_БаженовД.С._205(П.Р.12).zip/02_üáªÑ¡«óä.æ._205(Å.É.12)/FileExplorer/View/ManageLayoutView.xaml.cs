﻿using System.Windows.Controls;

namespace FileExplorer.View
{
    public partial class ManageLayoutView : UserControl
    {
        public ManageLayoutView()
        {
            InitializeComponent();
        }
    }
}
