﻿using DevExpress.Xpf.Core;

namespace FileExplorer.View
{
    public partial class WarmupView : DXTabbedWindow
    {
        public WarmupView()
        {
            InitializeComponent();
        }
    }
}
