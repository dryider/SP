﻿using System.Windows.Controls;

namespace FileExplorer.View
{
    public partial class RenameBatchView : UserControl
    {
        public RenameBatchView()
        {
            InitializeComponent();
        }
    }
}
