﻿using DevExpress.Xpf.Bars;

namespace FileExplorer.Controls
{
    public partial class MenuItemControl : BarButtonItem
    {
        public MenuItemControl()
        {
            InitializeComponent();
        }
    }
}
